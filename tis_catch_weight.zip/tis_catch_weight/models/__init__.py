# -*- coding: utf-8 -*-
# Copyright (C) 2017-Today  Technaureus Info Solutions(<http://technaureus.com/>).
from . import res_config_settings
from . import product_template
from . import sale
from . import purchase
from . import account_invoice
from . import stock_move
from . import stock_scrap
from . import stock_move_line
from . import stock_immediate_transfer
